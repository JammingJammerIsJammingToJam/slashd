"""A Programming Language"""

__version__ = "1.1.0"
from .slashd import *